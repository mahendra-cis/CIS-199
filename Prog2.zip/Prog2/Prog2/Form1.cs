﻿// Grading ID : S4571
// CIS 199-75
// Program 2
// Spring 2020
// Due: 3/9/2020
//Description: This program show the calculation for taxes from baseline to candidate. 

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            //Baseline plan 
            const int BASE_PLAN1 = 9700;// first baseline plan (lowest)
            const int BASE_PLAN2 = 39475;// second baseline plan
            const int BASE_PLAN3 = 84200;// third baseline plan
            const int BASE_PLAN4 = 160725;// fourth baseline plan
            const int BASE_PLAN5 = 204100;// fifth baseline plan
            const int BASE_PLAN6 = 510300;// sixth baseline plan (highest)

            //Baseline rate
            const double BASELINE_RATE1 = .10;// first tax rate (lowest)
            const double BASELINE_RATE2 = .12;// second tax rate
            const double BASELINE_RATE3 = .22;// third tax rate
            const double BASELINE_RATE4 = .24;// fourth tax rate
            const double BASELINE_RATE5 = .32;// fifth tax rate
            const double BASELINE_RATE6 = .35;// sixth tax rate (highest)

            // Candidate 1 and 3 plan
            const int CANDIDATE1_3PLAN1 = 9525; // first candidate plan (lowest)
            const int CANDIDATE1_3PLAN2 = 38700;// second candidate plan 
            const int CANDIDATE1_3PLAN3 = 82500;// third candidate plan 
            const int CANDIDATE1_3PLAN4 = 157500;// fourth candidate plan 
            const int CANDIDATE1_3PLAN5 = 200000;// fift candidate plan 
            const int CANDIDATE1_3PLAN6 = 500000;// sixth candidate plan (highest)

            // Candidate 1 and 3 rate 
            const double CANDIDATE1_3RATE1 = .10; // first tax rate (lowest)
            const double CANDIDATE1_3RATE2 = .15;// second tax rate
            const double CANDIDATE1_3RATE3 = .25;// third tax rate 
            const double CANDIDATE1_3RATE4 = .28;// fourth tax rate 
            const double CANDIDATE1_3RATE5 = .33;// fifth tax rate 
            const double CANDIDATE1_3RATE6 = .35;// sixth tax rate (highest)

            // Candidate 2 plan 
            const int CANDIDATE2_PLAN1 = 9525; // first candidate plan (lowest)
            const int CANDIDATE2_PLAN2 = 38700;// second candidate plan 
            const int CANDIDATE2_PLAN3 = 82500;// third candidate plan 
            const int CANDIDATE2_PLAN4 = 157500;// fouth candidate plan 
            const int CANDIDATE2_PLAN5 = 200000;// fifth candidate plan 
            const int CANDIDATE2_PLAN6 = 250000;// sixth candidate plan 
            const int CANDIDATE2_PLAN7 = 500000;// seventh candidate plan 
            const int CANDIDATE2_PLAN8 = 2000000;// eighth candidate plan 
            const int CANDIDATE2_PLAN9 = 10000000;// nineth candidate plan (highest)

            // Candidate 2 rate
            const double CANDIDATE2_RATE1 = .10; // first tax rate (lowest)
            const double CANDIDATE2_RATE2 = .12;// second tax rate 
            const double CANDIDATE2_RATE3 = .22;// third tax rate 
            const double CANDIDATE2_RATE4 = .24;// fouth tax rate 
            const double CANDIDATE2_RATE5 = .32;// fifth tax rate 
            const double CANDIDATE2_RATE6 = .35;// sixth tax rate
            const double CANDIDATE2_RATE7 = .40;// seventh tax rate 
            const double CANDIDATE2_RATE8 = .45;// eighth tax rate 
            const double CANDIDATE2_RATE9 = .50;// ninth tax rate (highest)

            // candidate extra rate and reduction
            const double candidate2ExtraRate = .4;// candidate 2 extra rate 
            const int candidate2ExtraThreshold = 29000;// candidate 2 extra threshold
            const double candidate3ReductionRate = .10;// candidate 3 reduction rate 
            const int candidate3ReductionThreshold = 200000;// candidate 3 reduction threshold



            double tax;
            int taxIncome;

            // calculation and result for baseline plan 1 with base line rate 1.
            if (int.TryParse(incomeResult.Text, out taxIncome))
            {
                if (baseRadio.Checked)// checked bottom
                {
                    if (taxIncome <= BASE_PLAN1)
                    {
                        marginalTaxRateResult.Text = $"{BASELINE_RATE1:P}";// calculation for baseline t
                        tax = taxIncome * BASELINE_RATE1;
                        incomeTaxResult.Text = $"{tax:C}";

                    }
                    else if (taxIncome <= BASE_PLAN2)
                    {
                        marginalTaxRateResult.Text = $"{BASELINE_RATE2:P}";
                        tax = (taxIncome - BASE_PLAN1) * BASELINE_RATE2 + (BASE_PLAN1 * BASELINE_RATE1);
                        incomeTaxResult.Text = $"{tax:C}";
                    }

                    else if (taxIncome <= BASE_PLAN3)
                    {
                        marginalTaxRateResult.Text = $"{BASELINE_RATE3:P}";
                        tax = (taxIncome - BASE_PLAN2) * BASELINE_RATE3 + (BASE_PLAN2 * BASELINE_RATE2);
                        incomeTaxResult.Text = $"{tax:C}";
                    }
                    else if (taxIncome <= BASE_PLAN4)
                    {
                        marginalTaxRateResult.Text = $"{BASELINE_RATE4:P}";
                        tax = (taxIncome - BASE_PLAN3) * BASELINE_RATE4 + (BASE_PLAN3 * BASELINE_RATE3);
                        incomeTaxResult.Text = $"{tax:C}";
                    }
                    else if (taxIncome <= BASE_PLAN5)
                    {
                        marginalTaxRateResult.Text = $"{BASELINE_RATE5:P}";
                        tax = (taxIncome - BASE_PLAN4) * BASELINE_RATE5 + (BASE_PLAN4 * BASELINE_RATE4);
                        incomeTaxResult.Text = $"{tax:C}";
                    }
                    else if (taxIncome <= BASE_PLAN6)
                    {
                        marginalTaxRateResult.Text = $"{BASELINE_RATE6:P}";
                        tax = (taxIncome - BASE_PLAN5) * BASELINE_RATE6 + (BASE_PLAN5 * BASELINE_RATE5);
                        incomeTaxResult.Text = $"{tax:C}";
                    }
                }


                // calculation and result for candidate plan 1 with candidate rate 1.
                if (candidateRad1.Checked)

                    if (taxIncome <= CANDIDATE1_3PLAN1)
                    {
                        marginalTaxRateResult.Text = $"{CANDIDATE1_3RATE1:P}";
                        tax = (taxIncome * CANDIDATE1_3RATE1);
                        incomeTaxResult.Text = $"{tax:C}";

                    }
                    else if (taxIncome <= CANDIDATE1_3PLAN2)
                    {
                        marginalTaxRateResult.Text = $"{CANDIDATE1_3RATE2:P}";
                        tax = (taxIncome - CANDIDATE1_3PLAN1) * CANDIDATE1_3RATE2 + (CANDIDATE1_3PLAN1 * CANDIDATE1_3RATE1);
                        incomeTaxResult.Text = $"{tax:C}";
                    }

                    else if (taxIncome <= CANDIDATE1_3PLAN3)
                    {
                        marginalTaxRateResult.Text = $"{CANDIDATE1_3RATE3:P}";
                        tax = (taxIncome - CANDIDATE1_3PLAN2) * CANDIDATE1_3RATE3 + (CANDIDATE1_3PLAN2 * CANDIDATE1_3RATE2);
                        incomeTaxResult.Text = $"{tax:C}";
                    }
                    else if (taxIncome <= CANDIDATE1_3PLAN4)
                    {
                        marginalTaxRateResult.Text = $"{CANDIDATE1_3RATE4:P}";
                        tax = (taxIncome - CANDIDATE1_3PLAN3) * CANDIDATE1_3RATE4 + (CANDIDATE1_3PLAN3 * CANDIDATE1_3RATE3);
                        incomeTaxResult.Text = $"{tax:C}";
                    }
                    else if (taxIncome <= CANDIDATE1_3PLAN5)
                    {
                        marginalTaxRateResult.Text = $"{CANDIDATE1_3RATE5:P}";
                        tax = (taxIncome - CANDIDATE1_3PLAN4) * CANDIDATE1_3RATE5 + (CANDIDATE1_3PLAN4 * CANDIDATE1_3RATE4);
                        incomeTaxResult.Text = $"{tax:C}";
                    }

                    else if (taxIncome <= CANDIDATE1_3PLAN6)
                    {
                        marginalTaxRateResult.Text = $"{CANDIDATE1_3RATE6:P}";
                        tax = (taxIncome - CANDIDATE1_3PLAN5) * CANDIDATE1_3RATE6 + (CANDIDATE1_3PLAN5 * CANDIDATE1_3RATE5);
                        incomeTaxResult.Text = $"{tax:C}";
                    }

                // calculation and result for candidate plan 3 and candidate rate 3 with reduction.
                if (candidateRad3.Checked)

                    if (taxIncome <= CANDIDATE1_3PLAN1)
                    {
                        marginalTaxRateResult.Text = $"{CANDIDATE1_3RATE1:P}";
                        tax = (taxIncome * .9 * CANDIDATE1_3RATE1);
                        incomeTaxResult.Text = $"{tax:C}";

                    }

                    else if (taxIncome <= CANDIDATE1_3PLAN2)
                    {
                        marginalTaxRateResult.Text = $"{CANDIDATE1_3RATE2:P}";
                        tax = (taxIncome - CANDIDATE1_3PLAN1) * candidate3ReductionRate;
                        incomeTaxResult.Text = $"{tax:C}";
                    }

                    else if (taxIncome <= CANDIDATE1_3PLAN3)
                    {
                        marginalTaxRateResult.Text = $"{CANDIDATE1_3RATE3:P}";
                        tax = (taxIncome - CANDIDATE1_3PLAN2) * candidate3ReductionRate;
                        incomeTaxResult.Text = $"{tax:C}";
                    }
                    else if (taxIncome <= CANDIDATE1_3PLAN4)
                    {
                        marginalTaxRateResult.Text = $"{CANDIDATE1_3RATE4:P}";
                        tax = (taxIncome - CANDIDATE1_3PLAN3)*candidate3ReductionRate;
                        incomeTaxResult.Text = $"{tax:C}"; 
                    }
                    else if (taxIncome <= CANDIDATE1_3PLAN5)
                    {
                        marginalTaxRateResult.Text = $"{CANDIDATE1_3RATE5:P}";
                        tax = (taxIncome - CANDIDATE1_3PLAN4) * candidate3ReductionRate;
                        incomeTaxResult.Text = $"{tax:C}";
                    }

                    else if (taxIncome <= CANDIDATE1_3PLAN6)
                    {
                        marginalTaxRateResult.Text = $"{CANDIDATE1_3RATE6:P}";
                        tax = (taxIncome - CANDIDATE1_3PLAN5) * CANDIDATE1_3RATE6;
                        incomeTaxResult.Text = $"{tax:C}";
                    }

                // calculation and result for candidate plan 2 and candidate rate 2 with reduction.
                if (candidateRad2.Checked)

                    if (taxIncome <= CANDIDATE2_PLAN1)
                    {
                        marginalTaxRateResult.Text = $"{CANDIDATE2_RATE1:P}";
                        tax = (taxIncome * CANDIDATE2_RATE1);
                        incomeTaxResult.Text = $"{tax:C}";
                    }
                    else if (taxIncome <= CANDIDATE2_PLAN2)
                    {
                        marginalTaxRateResult.Text = $"{CANDIDATE2_RATE2:P}";
                        tax = (taxIncome - CANDIDATE2_PLAN1) * ( CANDIDATE2_RATE2 ) + (CANDIDATE2_PLAN1 * CANDIDATE2_RATE1);
                        incomeTaxResult.Text = $"{tax:C}";
                    }

                    else if (taxIncome <= CANDIDATE2_PLAN3)
                    {
                        marginalTaxRateResult.Text = $"{CANDIDATE2_RATE3:P}";
                        tax = (taxIncome - CANDIDATE2_PLAN2) * (CANDIDATE2_RATE3) + (CANDIDATE2_PLAN2 * CANDIDATE2_RATE2)* candidate2ExtraRate;
                        incomeTaxResult.Text = $"{tax:C}";
                    }
                    else if (taxIncome <= CANDIDATE2_PLAN4)
                    {
                        marginalTaxRateResult.Text = $"{CANDIDATE2_RATE4:P}";
                        tax = (taxIncome - CANDIDATE2_PLAN3) * (CANDIDATE2_RATE4) + (CANDIDATE2_PLAN3 * CANDIDATE2_RATE3) * candidate2ExtraRate;
                        incomeTaxResult.Text = $"{tax:C}";
                    }
                    else if (taxIncome <= CANDIDATE2_PLAN5)
                    {
                        marginalTaxRateResult.Text = $"{CANDIDATE2_RATE5:P}";
                        tax = (taxIncome - CANDIDATE2_PLAN4) * (CANDIDATE2_RATE5) + (CANDIDATE2_PLAN4 * CANDIDATE2_RATE4) * candidate2ExtraRate;
                        incomeTaxResult.Text = $"{tax:C}";
                    }
                    else if (taxIncome <= CANDIDATE2_PLAN6)
                    {
                        marginalTaxRateResult.Text = $"{CANDIDATE2_RATE6:P}";
                        tax = (taxIncome - CANDIDATE2_PLAN5) * (CANDIDATE2_RATE6) + (CANDIDATE2_PLAN5 * CANDIDATE2_RATE5)* candidate2ExtraRate;
                        incomeTaxResult.Text = $"{tax:C}";
                    }
                    else if (taxIncome <= CANDIDATE2_PLAN7)
                    {
                        marginalTaxRateResult.Text = $"{CANDIDATE2_RATE7:P}";
                        tax = (taxIncome - CANDIDATE2_PLAN6) * (CANDIDATE2_RATE7) + (CANDIDATE2_PLAN6 * CANDIDATE2_RATE6)* candidate2ExtraRate;
                        incomeTaxResult.Text = $"{tax:C}";
                    }
                    else if (taxIncome <= CANDIDATE2_PLAN8)
                    {
                        marginalTaxRateResult.Text = $"{CANDIDATE2_RATE8:P}";
                        tax = (taxIncome - CANDIDATE2_PLAN7) * (CANDIDATE2_RATE8) + (CANDIDATE2_PLAN7 * CANDIDATE2_RATE7) * candidate2ExtraRate;
                        incomeTaxResult.Text = $"{tax:C}";
                    }
                    else if (taxIncome <= CANDIDATE2_PLAN9)
                    {
                        marginalTaxRateResult.Text = $"{CANDIDATE2_RATE9:P}";
                        tax = (taxIncome - CANDIDATE2_PLAN8) * (CANDIDATE2_RATE9) + (CANDIDATE2_PLAN8 * CANDIDATE2_RATE8)* (candidate2ExtraRate);
                        incomeTaxResult.Text = $"{tax:C}";
                    }
            }
                   
        }


    }

    }

    

