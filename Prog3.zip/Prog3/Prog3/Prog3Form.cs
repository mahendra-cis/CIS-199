﻿// Program 3
// Grading ID: S4571
// Cis 199-75
// Spring 2020
// Due date: 4/2/2020
// Description: This application calculates the marginal tax rate
// for various candidates' tax plans.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog3
{
    public partial class Prog3Form : Form
    {
        public Prog3Form()
        {
            InitializeComponent();
        }

        // User has clicked the Calculate Tax button
        // Will calculate and display their marginal tax rate
        private void calcTaxBtn_Click(object sender, EventArgs e)
        {

            // The marginal tax rates
            // Baseline
            const decimal BASE_RATE1 = .10m; // 1st tax rate (LOWEST)
            const decimal BASE_RATE2 = .12m; // 2nd tax rate
            const decimal BASE_RATE3 = .22m; // 3rd tax rate
            const decimal BASE_RATE4 = .24m; // 4th tax rate
            const decimal BASE_RATE5 = .32m; // 5th tax rate
            const decimal BASE_RATE6 = .35m; // 6th tax rate
            const decimal BASE_RATE7 = .37m; // 7th tax rate (HIGHEST)

            // Candidate 2
            const decimal C2_RATE1 = .10m;  // 1st tax rate (LOWEST)
            const decimal C2_RATE2 = .12m;  // 2nd tax rate
            const decimal C2_RATE3 = .22m;  // 3rd tax rate
            const decimal C2_RATE4 = .24m;  // 4th tax rate
            const decimal C2_RATE5 = .32m;  // 5th tax rate
            const decimal C2_RATE6 = .35m;  // 6th tax rate
            const decimal C2_RATE7 = .40m;  // 7th tax rate
            const decimal C2_RATE8 = .45m;  // 8th tax rate
            const decimal C2_RATE9 = .50m;  // 9th tax rate
            const decimal C2_RATE10 = .52m; // 10th tax rate (HIGHEST)

            // Taxable income thresholds for each candidate
            // Baseline
            const int BASE_THRESH1 = 9_700;   // 1st baseline threshold (LOWEST)
            const int BASE_THRESH2 = 39_475;  // 2nd baseline threshold
            const int BASE_THRESH3 = 84_200;  // 3rd baseline threshold
            const int BASE_THRESH4 = 160_725; // 4th baseline threshold
            const int BASE_THRESH5 = 204_100; // 5th baseline threshold
            const int BASE_THRESH6 = 510_300; // 6th baseline threshold (HIGHEST)

            // Candidate 2
            const int C2_THRESH1 = 9_525;     // 1st threshold (LOWEST)
            const int C2_THRESH2 = 38_700;    // 2nd threshold
            const int C2_THRESH3 = 82_500;    // 3rd threshold
            const int C2_THRESH4 = 157_500;   // 4th threshold
            const int C2_THRESH5 = 200_000;   // 5th threshold
            const int C2_THRESH6 = 250_000;   // 6th threshold
            const int C2_THRESH7 = 500_000;   // 7th threshold
            const int C2_THRESH8 = 2_000_000;  // 8th threshold
            const int C2_THRESH9 = 10_000_000; // 9th threshold (HIGHEST)


            // The marginal tax rates
            // Baseline rate and threshold in array 
            decimal[] BASE_RATE = { BASE_RATE1, BASE_RATE2, BASE_RATE3, BASE_RATE4, BASE_RATE5, BASE_RATE6, BASE_RATE7 }; // Baseline rate from lowest to highest
            int[] BASE_THRESH = { BASE_THRESH1, BASE_THRESH2, BASE_THRESH3, BASE_THRESH4, BASE_THRESH5, BASE_THRESH6 };  // Taxable income thresholds for each baseline

            // Candidate 2 rate and threshold in array 
            decimal[] CANDIDATE2_RATE = { C2_RATE1, C2_RATE2, C2_RATE3, C2_RATE4, C2_RATE5, C2_RATE6, C2_RATE7, C2_RATE8, C2_RATE9,C2_RATE10 }; // Candidate 2 rate from lowest to highest
            int[] C2_THRESH = { C2_THRESH1, C2_THRESH2, C2_THRESH3, C2_THRESH4, C2_THRESH5, C2_THRESH6, C2_THRESH7, C2_THRESH8, C2_THRESH9 }; // Taxable income thresholds for each candidate 2
           
            decimal percentage = 0; // percentages 
            bool found = false;// bool
            int x = 0;// declaring int 
            int income; // declaring income 

            if (int.TryParse(incomeTxt.Text, out income) && income >= 0)// using tryparse                                                                                            
            {
                if (baselineRdoBtn.Checked) // Baseline Button Clicked
                {
                    while (!found)// using while loop if not found output this below 
                    {
                        if (x == BASE_THRESH.Length || income <= BASE_THRESH[x]) // using OR operation for the loop 
                        {
                            found = true;// true
                            percentage = BASE_RATE[x]; // indexing 
                        }
                        x++;//increment
                    }
                }

                if (candidate2RdoBtn.Checked) // Candidate 2 Button Clicked
                {
                    while (!found)// using while loop 
                    {
                        if (x == C2_THRESH.Length || income <= C2_THRESH[x])// using OR operation for the loop 
                        {
                            found = true;//true
                            percentage = CANDIDATE2_RATE[x];// indexing 
                        }
                        x++;// increment
                    }
                }
               
                marginalRateOutLbl.Text = $"{percentage:P1}"; //Output results
            }
            else 
                MessageBox.Show("Enter valid income!");//Invalid input
        }
    }
}