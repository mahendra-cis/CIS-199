﻿//CIS 199-75
//Spring 2020
//Grading ID: S4571
// program 4
// Due: 4/21/2020
//Description: This program show the output of packaging and its loction that need to be send using array.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Program4
{
    class Program
    {
        // Precondition: None
        // Postcondition: Testing groundpackage
        public static void Main(string[] args)
        {
            GroundPackage gp1 = new GroundPackage(40204, 30102, 18, 43, 14, 53);// first groundpackage with length, width, height, and weight
            GroundPackage gp2 = new GroundPackage(60606, 42199, 11, 22, 90, 59);// second groundpackage with length, width, height, and weight
            GroundPackage gp3 = new GroundPackage(46224, 67908, 77, 54, 80, 86);// third groundpackage with length, width, height, and weight
            GroundPackage gp4 = new GroundPackage(30084, 56798, 29, 71, 44, 33);// fourth groundpackage with length, width, height, and weight
            GroundPackage gp5 = new GroundPackage(43026, 42310, 21, 20, 81, 95);// fifth groundpackage with length, width, height, and weight

            GroundPackage[] gp_Packages = { gp1, gp2, gp3, gp4, gp5 };// test for array

            
            DisplayPackages(gp_Packages);// displaying 

            gp1.Length = 53;// length value
            gp2.OriginZip = 59;// orginal zip value
            gp3.Width = 86;// width value
            gp4.Weight = 95;// weight value
            gp5.Height = 54;// height value

            DisplayPackages(gp_Packages);


        }
        public static void DisplayPackages(GroundPackage[] packages)// displaying using 
        {
            foreach (GroundPackage package in packages)
            {
                Console.WriteLine(package.ToString());// using to.string
                Console.WriteLine(package.CalcCost());// calcost
                
            }


        }
    }
}




