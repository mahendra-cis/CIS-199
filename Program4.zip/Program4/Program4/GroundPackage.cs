﻿//CIS 199-75
//Spring 2020
//Grading ID: S4571
// program 4
// Due: 4/21/2020
//Description: This program show the output of packaging and its loction that need to be send. 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program4
{
    public class GroundPackage
    {
        

        private int ORIGIN_ZIP; //  origin zip code for package
        private int DESTINATION_ZIP; // destination zip code for package
        private double HEIGHT = 0; //  height package
        private double WEIGHT = 0; //weight  package
        private double LENGTH = 0;// length  package
        private double WIDTH = 0; // width package

        public const int MIN_ZIPCODE = 00000;// min zip code 
        public const int MAX_ZIPCODE = 99999; // max zip code 
        public const int defaultoriginZip = 40204; // default origin zip code
        public const int defaultdestinationZip = 60606; // default destination zip code
        public const double  defaultDimension = 1; // default number for dimensions of package 
        public const int distanceDivider = 10000; // number used to find first digit of zip code
        public const double defaultLength = 12;// default length
        public const double defaultWeight = 12;// default weight
        public const double defaultHeight = 12;// default height
        public const double defaultWidth = 12;// default width
         const double SIZE_COST_FACTOR = .20;// magic number 
         const double WEIGHT_COST_FACTOR = .35;// magic number 



        // Precondition: All preconditions are met.
        // Postcondition: All the Package will be provide the information as such origin zip, destination zip, length, width, weight, height.
        public GroundPackage(int originationZip, int destinationZip, double length, double width,
             double height, double weightPounds)
        {
            OriginZip = originationZip;// declearing set
            DestinationZip = destinationZip;// declearing set
            Length = length;// declearing set
            Width = width;// declearing set
            Height = height;// declearing set
            Weight = weightPounds;// declearing set
        }
        public int OriginZip
        {
            // Precondition: no precondition
            // Postcondition: zip code will returned
            get
            {
                return ORIGIN_ZIP;
            }

            // Precondition: 00000 < value < 99999
            // Postcondition:  zip code had been set.
            set
            {
                if ((value > ORIGIN_ZIP) && (value < DESTINATION_ZIP))// if statement
                   ORIGIN_ZIP = value;
                else ORIGIN_ZIP = defaultoriginZip;// else statement
            }
        }
        public int DestinationZip
        {
            // Precondition: None
            // Postcondition: zip code will be returned.
            get
            {
                return DESTINATION_ZIP;
            }

            // Precondition: 00000 < value < 99999
            // Postcondition: Zip code will be set.
            set
            {
                if ((value > ORIGIN_ZIP) && (value < DESTINATION_ZIP))// if statement 
                    DESTINATION_ZIP = value;
                else DESTINATION_ZIP = defaultdestinationZip;// else statement
            }
        }
        public double Length
        {
            // Precondition: None
            // Postcondition: Length will be returned.
            get
            {
                return LENGTH;// return
            }

            // Precondition: value > 0
            // Postcondition: Length will be set
            set
            {
                if (value > LENGTH)// if statement 
                    LENGTH = value;
                else
                    LENGTH = defaultDimension;// else statement
            }
        }
        public double Width
        {
            // Precondition: None
            // Postcondition: width will be returned.
            get
            {
                return WIDTH;
            }

            // Precondition: value > 0
            // Postcondition: Width will be set.
            set
            {
                if (value > WIDTH)// if statement
                    WIDTH = value;
                else
                    WIDTH = defaultDimension;// else statement
            }
        }
        public double Height
        {
            // Precondition: None
            // Postcondition: Height will be returned.
            get
            {
                return HEIGHT;
            }

            // Precondition: value > 0
            // Postcondition: Height will be set
            set
            {
                if (value > HEIGHT)// if statement
                    HEIGHT = value;
                else
                    HEIGHT = defaultDimension;// else statement
            }
        }
        public double Weight
        {
            // Precondition: None
            // Postcondition: Weight will be returned.
            get
            {
                return WEIGHT;
            }

            // Precondition: value > 0
            // Postcondition: Weight will be set.
            set
            {
                if (value > WEIGHT)// if statement 
                    WEIGHT = value;
                else
                    WEIGHT = defaultDimension;// else statement
            }
        }
        public int ZoneDistance
        {
            // Precondition: None
            // Postcondition: Returns the zone distance of the positive number difference between the first two digits of the zip codes.
            get
            {
                return (ORIGIN_ZIP / distanceDivider) - (DESTINATION_ZIP / distanceDivider);// return
            }

        }
        public double CalcCost()
        {
            // Precondition: All variables have received valid input.
            // PostCondition: calcost will returned.

            return (SIZE_COST_FACTOR * (Length + Width + Height) + WEIGHT_COST_FACTOR * (ZoneDistance + 1) * (Weight));
        }
        // Precondition: None
        // Postcondition: string that returned ground packages data.
        public override string ToString()
        {
            return "OriginZip: " + ORIGIN_ZIP.ToString() + System.Environment.NewLine +
                "Destination Zip Code: " + DESTINATION_ZIP.ToString() + System.Environment.NewLine +
                "Length: " + LENGTH.ToString() + System.Environment.NewLine +
                "Width: " + WIDTH.ToString() + System.Environment.NewLine +
                "Height: " + HEIGHT.ToString() + System.Environment.NewLine +
                "Weight: " + WEIGHT.ToString() + System.Environment.NewLine;
               
        }
    }
}







