﻿// Grading ID: S4571
// Program 1 
// CIS 199-75
// Spring 2020
// Due:2/11/2020
// Description: This program shows the calutation for the Handy-Dandy Carpet Estimator
using System;
using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog1
{
    class Program
    {
        static void Main(string[] args)
        {
            // declearing the variable with names using const double 
            double width, length, carpetPrice, squareFeetNeeded, carpetCost, paddingCost, laborCost, totalCost;
            int padding, firstRoom;
            const double extraPaddingWaste = 1.1;
            const double extraYardPrice = 2.50;
            const double extraLaborPrice = 75.00;
            const double extraCharge = 4.25;
            const double feetToYard = 9;

            // declaring the input while using double.Parse 
            Console.WriteLine("Welcome to the Handy-Dandy Carpet Estimator");
            Console.WriteLine();

            Console.Write("Enter the max width of room (in feet): ");
            width = double.Parse(ReadLine());

            Console.Write("Enter the max length of room (in feet): ");
            length = double.Parse(ReadLine());

            Console.Write("Enter the carpet price (per sq. yard): ");
            carpetPrice = double.Parse(ReadLine());

            Console.Write("Enter layers of padding to use (1 or 2): ");
            padding = int.Parse(ReadLine());

            Console.Write("Is this the first room? (1 = YES, 0 = NO): ");
            firstRoom = int.Parse(ReadLine());

            Console.WriteLine();

            // calculation for all the output 
            squareFeetNeeded = length * width/feetToYard;
            carpetCost = carpetPrice/feetToYard * length * width * extraPaddingWaste;
            paddingCost = length * width/ feetToYard * extraPaddingWaste * extraYardPrice;
            laborCost = length * width / feetToYard * extraCharge + extraLaborPrice * firstRoom;
            totalCost = carpetCost + paddingCost + laborCost;

            // output using string interpolation as well as in currency formatting except the first one "Sq.yards needed" 
            Console.WriteLine($"Sq.Yards Needed:          {squareFeetNeeded:f1}");
            Console.WriteLine($"Carpet Cost:            {carpetCost:c2}");
            Console.WriteLine($"Padding Cost:           {paddingCost:c2}");  
            Console.WriteLine($"Labor Cost:             {laborCost:c2}");   
            Console.WriteLine($"Total Cost:           {totalCost:c2} ");




        }
    }
}
